pandastable package
===================

Submodules
----------

pandastable\.annotation module
------------------------------

.. automodule:: pandastable.annotation
    :members:
    :undoc-members:
    :show-inheritance:

pandastable\.app module
-----------------------

.. automodule:: pandastable.app
    :members:
    :undoc-members:
    :show-inheritance:

pandastable\.core module
------------------------

.. automodule:: pandastable.core
    :members:
    :undoc-members:
    :show-inheritance:

pandastable\.data module
------------------------

.. automodule:: pandastable.data
    :members:
    :undoc-members:
    :show-inheritance:

pandastable\.dialogs module
---------------------------

.. automodule:: pandastable.dialogs
    :members:
    :undoc-members:
    :show-inheritance:

pandastable\.handlers module
----------------------------

.. automodule:: pandastable.handlers
    :members:
    :undoc-members:
    :show-inheritance:

pandastable\.headers module
---------------------------

.. automodule:: pandastable.headers
    :members:
    :undoc-members:
    :show-inheritance:

pandastable\.images module
--------------------------

.. automodule:: pandastable.images
    :members:
    :undoc-members:
    :show-inheritance:

pandastable\.plotting module
----------------------------

.. automodule:: pandastable.plotting
    :members:
    :undoc-members:
    :show-inheritance:

pandastable\.plugin module
--------------------------

.. automodule:: pandastable.plugin
    :members:
    :undoc-members:
    :show-inheritance:

pandastable\.config module
-------------------------------

.. automodule:: pandastable.config
    :members:
    :undoc-members:
    :show-inheritance:

pandastable\.stats module
-------------------------

.. automodule:: pandastable.stats
    :members:
    :undoc-members:
    :show-inheritance:

pandastable\.tests module
-------------------------

.. automodule:: pandastable.tests
    :members:
    :undoc-members:
    :show-inheritance:

pandastable\.util module
------------------------

.. automodule:: pandastable.util
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: pandastable
    :members:
    :undoc-members:
    :show-inheritance:
